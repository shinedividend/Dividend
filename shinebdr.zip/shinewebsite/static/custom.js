function sumAll(){
	var i;
    var sum = 0;
    for(i = 0; i < arguments.length; i++) {
    	if (typeof arguments[i] === 'number' && !isNaN(arguments[i])){
        	sum += arguments[i];
        }
     }
     return sum;
}
p1 = getElementById("p1")
p2 = getElementById("p2")
p3 = getElementById("p3")
p4 = getElementById("p4")
document.getElementById("presult").innerHTML = sumAll(p1, p2, p3, p4);
