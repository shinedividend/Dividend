from django.db import models

class Stock(models.Model):
    ticker = models.CharField(max_length=20)
    company_name = models.CharField(max_length=100, null=True, blank=True)
    exchange = models.CharField(max_length=50, null=True, blank=True)
    sector = models.CharField(max_length=100, null=True, blank=True)
    price = models.FloatField(null=True, blank=True)
    initial_investment = models.FloatField(null=True, blank=True)
    commision = models.FloatField(null=True, blank=True)
    frequency = models.CharField(max_length=20, null=True, blank=True)
    dividend = models.FloatField(null=True, blank=True)
    dividend_yield = models.FloatField(null=True, blank=True)
    ex_dividend_date = models.DateField(null=True, blank=True)
    payment_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ticker
