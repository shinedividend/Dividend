from django.urls import path
from databank import views

urlpatterns = [
    path('', views.homepage),
]