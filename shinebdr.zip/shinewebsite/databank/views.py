from django.shortcuts import render
from databank.models import *
from django.contrib.auth.decorators import login_required
# Create your views here.
from api_data import *

@login_required
def homepage(request):
	if request.method == 'POST' and 'databank' in request.POST:
		symbol = request.POST.get('symbol')
		symbol = symbol.upper()
		frequency = request.POST.get('frequency')
		api_data = add_stock(symbol)
		Stock.objects.update_or_create(ticker=symbol, defaults={
			'company_name': api_data['company_name'],
			'sector': api_data['sector'],
			'frequency': frequency,
			'price': api_data['price'],
			'dividend': api_data['dividend'],
			'dividend_yield': api_data['dividend_yield'],
			'ex_dividend_date': api_data['ex_dividend_date'],
			'payment_date': api_data['pay_date'],
		})
	if request.method == 'POST' and 'delete_btn' in request.POST:
		ticker = request.POST.get('delete_symbol')
		Stock.objects.get(ticker=ticker).delete()
	stocks = Stock.objects.all().order_by('-created_at')
	return render(request,'databank/homepage.html', {'stocks': stocks,})

def add_stock(stock):
	api_data = get_dividend(stock)
	return api_data