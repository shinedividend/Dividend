from databank.models import *
from api_data import *

def update_databank():
    stocks = Stock.objects.all()
    for stock in stocks:
        api_data = add_stock(stock)
        if api_data:
            stock.company_name = api_data['company_name']
            stock.sector= api_data['sector']
            stock.price = api_data['price']
            stock.dividend = api_data['dividend']
            stock.dividend_yield = api_data['dividend_yield']
            stock.ex_dividend_date = api_data['ex_dividend_date']
            stock.payment_date = api_data['pay_date']
            stock.save()


def add_stock(stock):
    try:
        ticker = stock.ticker
        api_data = get_dividend(ticker)
        print(api_data)
        return api_data
    except:
        print(ticker)
        return None
