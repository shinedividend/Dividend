from django.urls import path
from monthly_chart import views

urlpatterns = [
    path('', views.homepage),
]