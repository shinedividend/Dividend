from django.urls import path
from semiannually import views

urlpatterns = [
    path('', views.homepage),
]