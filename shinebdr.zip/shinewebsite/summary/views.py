from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import *
from django.db.models import Sum, Avg
from portfolio.models import PortfolioStock
@login_required
def homepage(request):
    portfolios = PortfolioStock.objects.values_list('portfolio_name', flat=True)
    portfolio_name = portfolios.first()
    portfolios = list(set(portfolios))
    currency = 'CAD'
    year = 1
    if request.method == 'GET' and 'submitbtn' in request.GET:
        currency = request.GET['currency']
        year = request.GET['year-number']
        portfolio_name = request.GET['portfolio']
    if currency == 'CAD':
        exchange = 'TSX'
        exchange1 = 'CSE'
    else:
        exchange = 'NYSE'
        exchange1 = 'NASDAQ'
    stocks = SummaryStock.objects.filter(exchange=exchange, portfolio=portfolio_name) | SummaryStock.objects.filter(exchange=exchange1, portfolio=portfolio_name)
    if stocks:
        for stock in stocks:
            if stock.frequency == "Quarterly":
                quarter(stock, int(year))
            elif stock.frequency == "SemiAnnually":
                semiannually(stock, int(year))
            elif stock.frequency == "Annually":
                annually(stock, int(year))
            elif stock.frequency == "Monthly":
                month(stock, int(year))
        total, avg_yield = total_values(portfolio_name)
    else:
        total = None
        avg_yield = None
    return render(request, 'summary/homepage.html', {
        'total': total,
        'summaries': stocks,
        'portfolios': portfolios,
        'messages': f'Currency: {currency}  ||  Year: {year}  ||  Portfolio Average Yield: {format(avg_yield,".2f")}%',
    })

def quarter(stock, year):
    Share_Price = stock.price
    dividend = stock.dividend
    initial_investment = stock.initial_investment
    commision = stock.commision
    Cash_Available_for_INVESTMENT_Q1 = initial_investment - commision
    No_of_Shares_bought_in_Q1 = int(Cash_Available_for_INVESTMENT_Q1 / Share_Price)
    Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image = No_of_Shares_bought_in_Q1 * dividend
    Total_No_of_Share_With_Drip_end_of_Q4 = No_of_Shares_bought_in_Q1
    for i in range(1, year + 1):
        Dividend_Cash_Received_WITHOUT_DRIP_in_Q1 = Total_No_of_Share_With_Drip_end_of_Q4 * dividend
        potential_number_of_drip_shares_in_Q1 = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1 / Share_Price
        share_percentage_cash_balance_after_drip_Q1 = potential_number_of_drip_shares_in_Q1 - int(potential_number_of_drip_shares_in_Q1)
        Cash_Balance_Received_WITH_DRIP_in_Q1 = share_percentage_cash_balance_after_drip_Q1 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_Q1 = Total_No_of_Share_With_Drip_end_of_Q4 + int(potential_number_of_drip_shares_in_Q1)

        Dividend_Cash_Received_WITHOUT_DRIP_in_Q2_2 = Total_No_of_Shares_With_Drip_end_of_Q1 * dividend
        Potential_Number_of_Drip_Shares_in_Q2 = Dividend_Cash_Received_WITHOUT_DRIP_in_Q2_2 / Share_Price
        share_percentage_cash_balance_after_drip_Q2 = Potential_Number_of_Drip_Shares_in_Q2 - int(Potential_Number_of_Drip_Shares_in_Q2)
        Cash_Balance_Received_WITH_DRIP_in_Q2 = share_percentage_cash_balance_after_drip_Q2 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_Q2 = Total_No_of_Shares_With_Drip_end_of_Q1 + int(Potential_Number_of_Drip_Shares_in_Q2)

        Dividend_Cash_Received_WITHOUT_DRIP_in_Q3_2 = Total_No_of_Shares_With_Drip_end_of_Q2 * dividend
        potential_number_of_drip_shares_in_Q3 = Dividend_Cash_Received_WITHOUT_DRIP_in_Q3_2 / Share_Price
        share_percentage_cash_balance_after_drip_Q3 = potential_number_of_drip_shares_in_Q3 - int(potential_number_of_drip_shares_in_Q3)
        Cash_Balance_Received_WITH_DRIP_in_Q3 = share_percentage_cash_balance_after_drip_Q3 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_Q3 = Total_No_of_Shares_With_Drip_end_of_Q2 + int(potential_number_of_drip_shares_in_Q3)

        Dividend_Cash_Received_WITHOUT_DRIP_in_Q4_2 = Total_No_of_Shares_With_Drip_end_of_Q3 * dividend
        Potential_Number_of_Drip_Shares_in_Q4 = Dividend_Cash_Received_WITHOUT_DRIP_in_Q4_2 / Share_Price
        share_percentage_cash_balance_after_drip_Q4 = Potential_Number_of_Drip_Shares_in_Q4 - int(Potential_Number_of_Drip_Shares_in_Q4)
        Cash_Balance_Received_WITH_DRIP_in_Q4 = share_percentage_cash_balance_after_drip_Q4 * Share_Price
        Total_No_of_Share_With_Drip_end_of_Q4 = Total_No_of_Shares_With_Drip_end_of_Q3 + int(Potential_Number_of_Drip_Shares_in_Q2)

    stock.ai_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image * 4
    stock.stocks_number = int(No_of_Shares_bought_in_Q1)
    stock.jan_with = Cash_Balance_Received_WITH_DRIP_in_Q1
    stock.jan_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image
    stock.apr_with = Cash_Balance_Received_WITH_DRIP_in_Q2
    stock.apr_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image
    stock.jul_with = Cash_Balance_Received_WITH_DRIP_in_Q3
    stock.jul_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image
    stock.oct_with = Cash_Balance_Received_WITH_DRIP_in_Q4
    stock.oct_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Q1_image
    annual_income_with = Cash_Balance_Received_WITH_DRIP_in_Q1 + Cash_Balance_Received_WITH_DRIP_in_Q2 + Cash_Balance_Received_WITH_DRIP_in_Q3 + Cash_Balance_Received_WITH_DRIP_in_Q4
    stock.ai_with = annual_income_with
    stock.save()

def month(stock, year):
    Share_Price = stock.price
    dividend = stock.dividend
    initial_investment = stock.initial_investment
    commision = stock.commision
    Cash_Available_for_INVESTMENT_M1 = initial_investment - commision
    No_of_Shares_bought_in_M1 = int(Cash_Available_for_INVESTMENT_M1 / Share_Price)
    Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image = No_of_Shares_bought_in_M1 * dividend
    Total_No_of_Share_With_Drip_end_of_M12 = No_of_Shares_bought_in_M1
    for i in range(1, year + 1):
        Dividend_Cash_Received_WITHOUT_DRIP_in_M1 = Total_No_of_Share_With_Drip_end_of_M12 * dividend
        potential_number_of_drip_shares_in_M1 = Dividend_Cash_Received_WITHOUT_DRIP_in_M1 / Share_Price
        share_percentage_cash_balance_after_drip_M1 = potential_number_of_drip_shares_in_M1 - int(potential_number_of_drip_shares_in_M1)
        Cash_Balance_Received_WITH_DRIP_in_M1 = share_percentage_cash_balance_after_drip_M1 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M1 = Total_No_of_Share_With_Drip_end_of_M12 + int(potential_number_of_drip_shares_in_M1)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M2_2 = Total_No_of_Shares_With_Drip_end_of_M1 * dividend
        Potential_Number_of_Drip_Shares_in_M2 = Dividend_Cash_Received_WITHOUT_DRIP_in_M2_2 / Share_Price
        share_percentage_cash_balance_after_drip_M2 = Potential_Number_of_Drip_Shares_in_M2 - int(Potential_Number_of_Drip_Shares_in_M2)
        Cash_Balance_Received_WITH_DRIP_in_M2 = share_percentage_cash_balance_after_drip_M2 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M2 = Total_No_of_Shares_With_Drip_end_of_M1 + int(Potential_Number_of_Drip_Shares_in_M2)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M3_2 = Total_No_of_Shares_With_Drip_end_of_M2 * dividend
        potential_number_of_drip_shares_in_M3 = Dividend_Cash_Received_WITHOUT_DRIP_in_M3_2 / Share_Price
        share_percentage_cash_balance_after_drip_M3 = potential_number_of_drip_shares_in_M3 - int(potential_number_of_drip_shares_in_M3)
        Cash_Balance_Received_WITH_DRIP_in_M3 = share_percentage_cash_balance_after_drip_M3 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M3 = Total_No_of_Shares_With_Drip_end_of_M2 + int(potential_number_of_drip_shares_in_M3)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M4_2 = Total_No_of_Shares_With_Drip_end_of_M3 * dividend
        Potential_Number_of_Drip_Shares_in_M4 = Dividend_Cash_Received_WITHOUT_DRIP_in_M4_2 / Share_Price
        share_percentage_cash_balance_after_drip_M4 = Potential_Number_of_Drip_Shares_in_M4 - int(Potential_Number_of_Drip_Shares_in_M4)
        Cash_Balance_Received_WITH_DRIP_in_M4 = share_percentage_cash_balance_after_drip_M4 * Share_Price
        Total_No_of_Share_With_Drip_end_of_M4 = Total_No_of_Shares_With_Drip_end_of_M3 + int(Potential_Number_of_Drip_Shares_in_M2)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M5 = Total_No_of_Share_With_Drip_end_of_M4 * dividend
        potential_number_of_drip_shares_in_M5 = Dividend_Cash_Received_WITHOUT_DRIP_in_M5 / Share_Price
        share_percentage_cash_balance_after_drip_M5 = potential_number_of_drip_shares_in_M5 - int(potential_number_of_drip_shares_in_M5)
        Cash_Balance_Received_WITH_DRIP_in_M5 = share_percentage_cash_balance_after_drip_M5 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M5 = Total_No_of_Share_With_Drip_end_of_M4 + int(potential_number_of_drip_shares_in_M5)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M6_2 = Total_No_of_Shares_With_Drip_end_of_M5 * dividend
        Potential_Number_of_Drip_Shares_in_M6 = Dividend_Cash_Received_WITHOUT_DRIP_in_M6_2 / Share_Price
        share_percentage_cash_balance_after_drip_M6 = Potential_Number_of_Drip_Shares_in_M6 - int(Potential_Number_of_Drip_Shares_in_M6)
        Cash_Balance_Received_WITH_DRIP_in_M6 = share_percentage_cash_balance_after_drip_M6 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M6 = Total_No_of_Shares_With_Drip_end_of_M5 + int(Potential_Number_of_Drip_Shares_in_M6)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M7_2 = Total_No_of_Shares_With_Drip_end_of_M6 * dividend
        potential_number_of_drip_shares_in_M7 = Dividend_Cash_Received_WITHOUT_DRIP_in_M7_2 / Share_Price
        share_percentage_cash_balance_after_drip_M7 = potential_number_of_drip_shares_in_M7 - int(potential_number_of_drip_shares_in_M7)
        Cash_Balance_Received_WITH_DRIP_in_M7 = share_percentage_cash_balance_after_drip_M7 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M7 = Total_No_of_Shares_With_Drip_end_of_M6 + int(potential_number_of_drip_shares_in_M7)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M8_2 = Total_No_of_Shares_With_Drip_end_of_M7 * dividend
        Potential_Number_of_Drip_Shares_in_M8 = Dividend_Cash_Received_WITHOUT_DRIP_in_M8_2 / Share_Price
        share_percentage_cash_balance_after_drip_M8 = Potential_Number_of_Drip_Shares_in_M8 - int(Potential_Number_of_Drip_Shares_in_M8)
        Cash_Balance_Received_WITH_DRIP_in_M8 = share_percentage_cash_balance_after_drip_M8 * Share_Price
        Total_No_of_Share_With_Drip_end_of_M8 = Total_No_of_Shares_With_Drip_end_of_M7 + int(Potential_Number_of_Drip_Shares_in_M6)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M9 = Total_No_of_Share_With_Drip_end_of_M8 * dividend
        potential_number_of_drip_shares_in_M9 = Dividend_Cash_Received_WITHOUT_DRIP_in_M9 / Share_Price
        share_percentage_cash_balance_after_drip_M9 = potential_number_of_drip_shares_in_M9 - int(potential_number_of_drip_shares_in_M9)
        Cash_Balance_Received_WITH_DRIP_in_M9 = share_percentage_cash_balance_after_drip_M9 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M9 = Total_No_of_Share_With_Drip_end_of_M8 + int(potential_number_of_drip_shares_in_M9)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M10_2 = Total_No_of_Shares_With_Drip_end_of_M9 * dividend
        Potential_Number_of_Drip_Shares_in_M10 = Dividend_Cash_Received_WITHOUT_DRIP_in_M10_2 / Share_Price
        share_percentage_cash_balance_after_drip_M10 = Potential_Number_of_Drip_Shares_in_M10 - int(Potential_Number_of_Drip_Shares_in_M10)
        Cash_Balance_Received_WITH_DRIP_in_M10 = share_percentage_cash_balance_after_drip_M10 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M10 = Total_No_of_Shares_With_Drip_end_of_M9 + int(Potential_Number_of_Drip_Shares_in_M10)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M11_2 = Total_No_of_Shares_With_Drip_end_of_M10 * dividend
        potential_number_of_drip_shares_in_M11 = Dividend_Cash_Received_WITHOUT_DRIP_in_M11_2 / Share_Price
        share_percentage_cash_balance_after_drip_M11 = potential_number_of_drip_shares_in_M11 - int(potential_number_of_drip_shares_in_M11)
        Cash_Balance_Received_WITH_DRIP_in_M11 = share_percentage_cash_balance_after_drip_M11 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_M11 = Total_No_of_Shares_With_Drip_end_of_M10 + int(potential_number_of_drip_shares_in_M11)

        Dividend_Cash_Received_WITHOUT_DRIP_in_M12_2 = Total_No_of_Shares_With_Drip_end_of_M11 * dividend
        Potential_Number_of_Drip_Shares_in_M12 = Dividend_Cash_Received_WITHOUT_DRIP_in_M12_2 / Share_Price
        share_percentage_cash_balance_after_drip_M12 = Potential_Number_of_Drip_Shares_in_M12 - int(Potential_Number_of_Drip_Shares_in_M12)
        Cash_Balance_Received_WITH_DRIP_in_M12 = share_percentage_cash_balance_after_drip_M12 * Share_Price
        Total_No_of_Share_With_Drip_end_of_M12 = Total_No_of_Shares_With_Drip_end_of_M11 + int(Potential_Number_of_Drip_Shares_in_M10)

    stock.ai_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image * 12
    stock.stocks_number = int(No_of_Shares_bought_in_M1)
    stock.jan_with = Cash_Balance_Received_WITH_DRIP_in_M1
    stock.jan_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.feb_with = Cash_Balance_Received_WITH_DRIP_in_M2
    stock.feb_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.mar_with = Cash_Balance_Received_WITH_DRIP_in_M3
    stock.mar_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.apr_with = Cash_Balance_Received_WITH_DRIP_in_M4
    stock.apr_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.may_with = Cash_Balance_Received_WITH_DRIP_in_M5
    stock.may_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.jun_with = Cash_Balance_Received_WITH_DRIP_in_M6
    stock.jun_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.jul_with = Cash_Balance_Received_WITH_DRIP_in_M7
    stock.jul_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.aug_with = Cash_Balance_Received_WITH_DRIP_in_M8
    stock.aug_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.sep_with = Cash_Balance_Received_WITH_DRIP_in_M9
    stock.sep_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.oct_with = Cash_Balance_Received_WITH_DRIP_in_M10
    stock.oct_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.nov_with = Cash_Balance_Received_WITH_DRIP_in_M11
    stock.nov_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image
    stock.dec_with = Cash_Balance_Received_WITH_DRIP_in_M12
    stock.dec_without = Dividend_Cash_Received_WITHOUT_DRIP_in_M1_image

    annual_income_with = Cash_Balance_Received_WITH_DRIP_in_M1 * 12
    stock.ai_with = annual_income_with
    stock.save()

def semiannually(stock, year):
    Share_Price = stock.price
    dividend = stock.dividend
    initial_investment = stock.initial_investment
    commision = stock.commision
    Cash_Available_for_INVESTMENT_H1 = initial_investment - commision
    No_of_Shares_bought_in_H1 = int(Cash_Available_for_INVESTMENT_H1 / Share_Price)
    Dividend_Cash_Received_WITHOUT_DRIP_in_H1_image = No_of_Shares_bought_in_H1 * dividend
    Total_No_of_Shares_With_Drip_end_of_H2 = No_of_Shares_bought_in_H1
    for i in range(1, year + 1):
        Dividend_Cash_Received_WITHOUT_DRIP_in_H1 = Total_No_of_Shares_With_Drip_end_of_H2 * dividend
        potential_number_of_drip_shares_in_H1 = Dividend_Cash_Received_WITHOUT_DRIP_in_H1 / Share_Price
        share_percentage_cash_balance_after_drip_H1 = potential_number_of_drip_shares_in_H1 - int(potential_number_of_drip_shares_in_H1)
        Cash_Balance_Received_WITH_DRIP_in_H1 = share_percentage_cash_balance_after_drip_H1 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_H1 = Total_No_of_Shares_With_Drip_end_of_H2 + int(potential_number_of_drip_shares_in_H1)

        Dividend_Cash_Received_WITHOUT_DRIP_in_H2_2 = Total_No_of_Shares_With_Drip_end_of_H1 * dividend
        Potential_Number_of_Drip_Shares_in_H2 = Dividend_Cash_Received_WITHOUT_DRIP_in_H2_2 / Share_Price
        share_percentage_cash_balance_after_drip_H2 = Potential_Number_of_Drip_Shares_in_H2 - int(Potential_Number_of_Drip_Shares_in_H2)
        Cash_Balance_Received_WITH_DRIP_in_H2 = share_percentage_cash_balance_after_drip_H2 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_H2 = Total_No_of_Shares_With_Drip_end_of_H1 + int(Potential_Number_of_Drip_Shares_in_H2)

    stock.ai_without = Dividend_Cash_Received_WITHOUT_DRIP_in_H1_image * 2
    stock.stocks_number = int(No_of_Shares_bought_in_H1)
    stock.jan_with = Cash_Balance_Received_WITH_DRIP_in_H1
    stock.jan_without = Dividend_Cash_Received_WITHOUT_DRIP_in_H1_image
    stock.jul_with = Cash_Balance_Received_WITH_DRIP_in_H2
    stock.jul_without = Dividend_Cash_Received_WITHOUT_DRIP_in_H1_image
    annual_income_with = Cash_Balance_Received_WITH_DRIP_in_H1 + Cash_Balance_Received_WITH_DRIP_in_H2
    stock.ai_with = annual_income_with
    stock.save()

def annually(stock, year):
    Share_Price = stock.price
    dividend = stock.dividend
    initial_investment = stock.initial_investment
    commision = stock.commision
    Cash_Available_for_INVESTMENT_Y1 = initial_investment - commision
    No_of_Shares_bought_in_Y1 = int(Cash_Available_for_INVESTMENT_Y1 / Share_Price)
    Dividend_Cash_Received_WITHOUT_DRIP_in_Y1_image = No_of_Shares_bought_in_Y1 * dividend
    Total_No_of_Shares_With_Drip_end_of_Y1 = No_of_Shares_bought_in_Y1
    for i in range(1, year + 1):
        Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 = Total_No_of_Shares_With_Drip_end_of_Y1 * dividend
        potential_number_of_drip_shares_in_Y1 = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 / Share_Price
        share_percentage_cash_balance_after_drip_Y1 = potential_number_of_drip_shares_in_Y1 - int(potential_number_of_drip_shares_in_Y1)
        Cash_Balance_Received_WITH_DRIP_in_Y1 = share_percentage_cash_balance_after_drip_Y1 * Share_Price
        Total_No_of_Shares_With_Drip_end_of_Y1 = Total_No_of_Shares_With_Drip_end_of_Y1 + int(potential_number_of_drip_shares_in_Y1)

    stock.ai_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1_image
    stock.stocks_number = int(No_of_Shares_bought_in_Y1)
    stock.jan_with = Cash_Balance_Received_WITH_DRIP_in_Y1
    stock.jan_without = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1_image
    annual_income_with = Cash_Balance_Received_WITH_DRIP_in_Y1
    stock.ai_with = annual_income_with
    stock.save()

def total_values(portfolio_name):
    total = {}
    stocks = SummaryStock.objects.filter(portfolio=portfolio_name)
    total['annual_w'] = stocks.aggregate(Sum('ai_with'))['ai_with__sum']
    total['annual_wo'] = stocks.aggregate(Sum('ai_without'))['ai_without__sum']
    total['jan_w'] = stocks.aggregate(Sum('jan_with'))['jan_with__sum']
    total['jan_wo'] = stocks.aggregate(Sum('jan_without'))['jan_without__sum']
    total['feb_w'] = stocks.aggregate(Sum('feb_with'))['feb_with__sum']
    total['feb_wo'] = stocks.aggregate(Sum('feb_without'))['feb_without__sum']
    total['mar_w'] = stocks.aggregate(Sum('mar_with'))['mar_with__sum']
    total['mar_wo'] = stocks.aggregate(Sum('mar_without'))['mar_without__sum']
    total['apr_w'] = stocks.aggregate(Sum('apr_with'))['apr_with__sum']
    total['apr_wo'] = stocks.aggregate(Sum('apr_without'))['apr_without__sum']
    total['may_w'] = stocks.aggregate(Sum('may_with'))['may_with__sum']
    total['may_wo'] = stocks.aggregate(Sum('may_without'))['may_without__sum']
    total['jun_w'] = stocks.aggregate(Sum('jun_with'))['jun_with__sum']
    total['jun_wo'] = stocks.aggregate(Sum('jun_without'))['jun_without__sum']
    total['jul_w'] = stocks.aggregate(Sum('jul_with'))['jul_with__sum']
    total['jul_wo'] = stocks.aggregate(Sum('jul_without'))['jul_without__sum']
    total['aug_w'] = stocks.aggregate(Sum('aug_with'))['aug_with__sum']
    total['aug_wo'] = stocks.aggregate(Sum('aug_without'))['aug_without__sum']
    total['sep_w'] = stocks.aggregate(Sum('sep_with'))['sep_with__sum']
    total['sep_wo'] = stocks.aggregate(Sum('sep_without'))['sep_without__sum']
    total['oct_w'] = stocks.aggregate(Sum('oct_with'))['oct_with__sum']
    total['oct_wo'] = stocks.aggregate(Sum('oct_without'))['oct_without__sum']
    total['nov_w'] = stocks.aggregate(Sum('nov_with'))['nov_with__sum']
    total['nov_wo'] = stocks.aggregate(Sum('nov_without'))['nov_without__sum']
    total['dec_w'] = stocks.aggregate(Sum('dec_with'))['dec_with__sum']
    total['dec_wo'] = stocks.aggregate(Sum('dec_without'))['dec_without__sum']
    return total, stocks.aggregate(Avg('yield_y'))['yield_y__avg']