from django.urls import path
from quarterly_chart import views

urlpatterns = [
    path('', views.homepage),
]