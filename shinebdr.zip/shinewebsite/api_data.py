#Please dont delete this

import requests

def get_dividend(ticker):
    url = "https://apidojo-yahoo-finance-v1.p.rapidapi.com/stock/v2/get-summary"
    querystring = {"symbol": ticker}
    headers = {
        'x-rapidapi-key': "407e5459c5msh75afa459d43eacep19ce25jsnf4d86076258d",
        'x-rapidapi-host': "apidojo-yahoo-finance-v1.p.rapidapi.com"
    }
    response = requests.request("GET", url, headers=headers, params=querystring)
    json_dict = response.json()
    api_data = {}
    quote = json_dict['quoteType']
    if quote:
        api_data['company_name'] = quote['longName']

    summary = json_dict['summaryDetail']
    if summary:
        try:
            api_data['dividend'] = float(summary['dividendRate']['fmt']) / 4
        except:
            api_data['dividend'] = 0
        try:
            api_data['dividend_yield'] = summary['dividendYield']['raw'] * 100
        except:
            api_data['dividend_yield'] = 0

    calenderEvent = json_dict['calendarEvents']
    if calenderEvent:
        try:
            api_data['ex_dividend_date'] = calenderEvent['exDividendDate']['fmt']
        except:
            api_data['ex_dividend_date'] = None
        try:
            api_data['pay_date'] = calenderEvent['dividendDate']['fmt']
        except:
            api_data['pay_date'] = None
    try:
        api_data['price'] = json_dict['financialData']['currentPrice']['fmt']
    except:
        api_data['price'] = 0
    try:
        api_data['sector'] = json_dict['summaryProfile']['sector']
    except:
        api_data['sector'] = None

    print(api_data)
    return api_data

def get_qoute(ticker):
    api_data = {}
    url = "https://apidojo-yahoo-finance-v1.p.rapidapi.com/stock/v2/get-summary"
    querystring = {"symbol": ticker}
    headers = {
        'x-rapidapi-key': "407e5459c5msh75afa459d43eacep19ce25jsnf4d86076258d",
        'x-rapidapi-host': "apidojo-yahoo-finance-v1.p.rapidapi.com"
    }
    response = requests.request("GET", url, headers=headers, params=querystring)
    json_dict = response.json()
    try:
        quote = json_dict['quoteType']
        if quote:
            api_data['company_name'] = quote['longName']
        all = json_dict['price']
        api_data['symbol'] = symbol
        try:
            api_data['exchange'] = all['exchange']
        except:
            api_data['exchange'] = None
        try:
            api_data['time'] = all['regularMarketTime']
        except:
            api_data['time'] = None
        try:
            api_data['high'] = all['regularMarketDayHigh']['raw']
        except:
            api_data['high'] = 0.0
        try:
            api_data['change'] = all['regularMarketChange']['raw']
        except:
            api_data['change'] = 0.0
        try:
            api_data['changePercent'] = all['regularMarketChangePercent']['raw']
        except:
            api_data['changePercent'] = 0.0
        try:
            api_data['low'] = all['regularMarketDayLow']['raw']
        except:
            api_data['low'] = 0.0
        try:
            api_data['last'] = all['regularMarketPreviousClose']['raw']
        except:
            api_data['last'] = 0.0
        try:
            api_data['price'] = all['regularMarketPrice']['raw']
        except:
            api_data['price'] = 0.0
        try:
            api_data['volume']= all['regularMarketVolume']['raw']
        except:
            api_data['volume']= 0
    except Exception as e:
        print(e)
        api_data['exchange'] = None
        api_data['time'] = None
        api_data['high'] = 0.0
        api_data['change'] = 0.0
        api_data['changePercent'] = 0.0
        api_data['low'] = 0.0
        api_data['price'] = 0.0
        api_data['last'] = 0.0
        api_data['volume'] = 0
    return api_data
