from django.urls import path
from annually import views

urlpatterns = [
    path('', views.homepage),
]