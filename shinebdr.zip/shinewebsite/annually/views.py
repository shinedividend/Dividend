from django.shortcuts import render, redirect
from databank.models import *
from portfolio.models import *
from summary.models import *
from django.contrib.auth.decorators import login_required
from api_data import *

@login_required
def homepage(request):
	input = {}
	input['commision'] = 9.99
	if request.method == 'POST' and 'btnform' in request.POST:
		symbol = request.POST.get('symbol')
		symbol = symbol.upper()
		initial_investment = request.POST.get('initial-investment')
		commision = request.POST.get('commision')
		frequency = request.POST.get('frequency')
		year_number = request.POST.get('quarter-number')
		portfolio_name = request.POST.get('portfolio')
		input['portfolio'] = portfolio_name
		input['commision'] = commision
		input['symbol'] = symbol
		input['initial_investment'] = initial_investment
		if symbol and commision and initial_investment:
			try:
				stock = Stock.objects.get(ticker=symbol)
			except Stock.DoesNotExist:
				stock = Stock.objects.create(ticker=symbol)
			api_data = add_stock(stock, float(initial_investment), float(commision), frequency)
			summary(symbol, api_data, portfolio_name)
			y1,y2 = calculations(float(initial_investment), float(commision), api_data, int(year_number))
			return render(request, 'annually/homepage.html', {
					'input': input,
					'stock': stock,
					'year1': y1,
					'year': y2,
					'message': f'<div class="alert table_bar" role="alert">Symbol: {symbol} | Initial Investment: {initial_investment} | Commission: {commision} | Year : {year_number}</div>'
				})
	if request.method == 'POST' and 'btnportfolio' in request.POST:
		symbol = request.POST.get('symbol')
		symbol = symbol.upper()
		portfolio_name = request.POST.get('portfolio')
		initial_investment = request.POST.get('initial-investment')
		commision = request.POST.get('commision')
		portfolio(symbol, float(initial_investment), float(commision), portfolio_name)
		return redirect('/portfolio')
	portfolio_stocks = PortfolioStock.objects.values_list('portfolio_name', flat=True).distinct()
	databank_stocks = Stock.objects.values_list('ticker', flat=True).distinct()
	return render(request, 'annually/homepage.html', {'portfolio_stocks': portfolio_stocks,
													  'databank_stocks': databank_stocks,
													  'input': input})

def add_stock(stock, initial_investment, commision, frequency):
	api_data = get_dividend(stock.ticker)
	api_data['initial_investment'] = initial_investment
	api_data['commision'] = commision
	api_data['frequency'] = frequency
	stock.company_name = api_data['company_name']
	stock.frequency = api_data['frequency']
	if stock.initial_investment == None:
		stock.initial_investment = api_data['initial_investment']
	elif stock.initial_investment == api_data['initial_investment']:
		pass
	else:
		i_i = stock.initial_investment + float(api_data['initial_investment'])
		stock.initial_investment = i_i
		api_data['initial_investment'] = i_i
	stock.commision = api_data['commision']
	stock.dividend = api_data['dividend']
	stock.dividend_yield = None
	stock.ex_dividend_date = api_data['ex_dividend_date']
	stock.price = api_data['price']
	stock.sector = api_data['sector']
	stock.payment_date = api_data['pay_date']
	stock.save()
	return api_data

def calculations(initial_investment, commission, api_data, year_number):
	y1, y2 = {}, {}
	if year_number >= 1:
		Share_Price = float(api_data['price'])
		dividend = api_data['dividend']
		y1['initial_investment'] = initial_investment
		y1['commission'] = commission
		Cash_Available_for_INVESTMENT_Y1 = initial_investment - commission
		y1['Cash_Available_for_INVESTMENT_Y1'] = Cash_Available_for_INVESTMENT_Y1
		potential_shares_for_investment = Cash_Available_for_INVESTMENT_Y1 / Share_Price
		y1['potential_shares_for_investment'] = potential_shares_for_investment
		y1['No_of_Shares_bought_in_Y1'] = int(potential_shares_for_investment)
		share_percentage_after_investment_in_Y1 = potential_shares_for_investment - int(potential_shares_for_investment)
		y1['Share_Percentage_after_investment_in_Y1'] = share_percentage_after_investment_in_Y1
		y1['investment_cash_Y1'] = int(potential_shares_for_investment) * Share_Price
		y1['CASH_BALANCE_in_Account_after_Investment_Y1'] = Share_Price * share_percentage_after_investment_in_Y1
		Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 = int(potential_shares_for_investment) * dividend
		y1['dividend_cash_received_WITHOUT_DRIP_in_Y1'] = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1
		potential_number_of_drip_shares_in_Y1 = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 / Share_Price
		y1['potential_number_of_drip_shares_in_Y1'] = potential_number_of_drip_shares_in_Y1
		y1['no_of_drip_shares_received_in_Y1'] = int(potential_number_of_drip_shares_in_Y1)
		share_percentage_cash_balance_after_drip = potential_number_of_drip_shares_in_Y1 - int(potential_number_of_drip_shares_in_Y1)
		y1['share_percentage_cash_balance_after_drip_Y1'] = share_percentage_cash_balance_after_drip
		y1['cash_balance_received_WITH_DRIP_in_Y1'] = share_percentage_cash_balance_after_drip * Share_Price
		Total_No_of_Shares_With_Drip_end_of_Y1 = int(potential_shares_for_investment) + int(potential_number_of_drip_shares_in_Y1)
		y1['total_no_of_shares_with_drip_end_of_Y1'] = Total_No_of_Shares_With_Drip_end_of_Y1
		Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y2_WITH_DRIP = Share_Price * Total_No_of_Shares_With_Drip_end_of_Y1
		y1['Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP1'] = Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y2_WITH_DRIP
	if year_number >= 2:
		for i in range(2,year_number+1):
			dividend_cash_received_WITHOUT_DRIP_in_Y = Total_No_of_Shares_With_Drip_end_of_Y1 * dividend
			y2['dividend_cash_received_WITHOUT_DRIP_in_Y' + str(i)] = dividend_cash_received_WITHOUT_DRIP_in_Y
			potential_number_of_drip_shares_in_Y = dividend_cash_received_WITHOUT_DRIP_in_Y / Share_Price
			y2['potential_number_of_drip_shares_in_Y' + str(i)] = potential_number_of_drip_shares_in_Y
			y2['no_of_drip_shares_received_in_Y' + str(i)] = int(potential_number_of_drip_shares_in_Y)
			share_percentage_cash_balance_after_drip = potential_number_of_drip_shares_in_Y - int(potential_number_of_drip_shares_in_Y)
			y2['share_percentage_cash_balance_after_drip_Y' + str(i)] = share_percentage_cash_balance_after_drip
			y2['cash_balance_received_WITH_DRIP_in_Y' + str(i)] = share_percentage_cash_balance_after_drip * Share_Price
			Total_No_of_Shares_With_Drip_end_of_Y1 = Total_No_of_Shares_With_Drip_end_of_Y1 + int(potential_number_of_drip_shares_in_Y)
			y2['total_no_of_shares_with_drip_end_of_Y' + str(i)] = Total_No_of_Shares_With_Drip_end_of_Y1
			Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP = Share_Price * Total_No_of_Shares_With_Drip_end_of_Y1
			y2['Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP' + str(i)] = Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP
	return y1,y2

def portfolio(ticker, initial_investment, commission, portfolio_name):
	api_data = get_dividend(ticker)
	if '.TO' in ticker or '.CN' in ticker or '.V' in ticker:
		currency = 'CAD'
	else:
		currency = 'USD'
	price = api_data['price']
	Cash_Available_for_INVESTMENT_Q1 = initial_investment - commission
	quantity = int(Cash_Available_for_INVESTMENT_Q1 / price)
	avg_cost = (quantity*price)+commission
	avg_cost = avg_cost/quantity
	mkt_value = quantity * price
	book_cost = quantity * avg_cost
	gain_loss = mkt_value - book_cost
	# PortfolioStock.objects.all().aggregate(Sum('mkt_value'))['mkt_value__sum']
	PortfolioStock.objects.update_or_create(ticker=ticker, portfolio_name=portfolio_name,
													 defaults={
														 'company_name':api_data['company_name'],
														 'sector':api_data['sector'],
														 'currency': currency,
														 'price': price,
														 'quantity':quantity,
														 'avg_cost':avg_cost,
														 'mkt_value':mkt_value,
														 'book_cost':book_cost,
														 'gain_loss':gain_loss,
														 'glpercentage':gain_loss/book_cost * 100,
														 'stock_yield':api_data['dividend_yield'],
													 })

def summary(symbol, api_data, portfolio_name):
	Cash_Available_for_INVESTMENT_Q1 = float(api_data['initial_investment']) - float(api_data['commision'])
	quantity = int(Cash_Available_for_INVESTMENT_Q1 / float(api_data['price']))
	avg_cost = (quantity * float(api_data['price'])) + float(api_data['commision'])
	avg_cost = avg_cost / quantity
	SummaryStock.objects.update_or_create(ticker=symbol, portfolio=portfolio_name,
										  defaults={
											  'company_name': api_data['company_name'],
											  'sector': api_data['sector'],
											  'frequency': api_data['frequency'],
											  'price': api_data['price'],
											  'avg_price': avg_cost,
											  'initial_investment': api_data['initial_investment'],
											  'commision': api_data['commision'],
											  'dividend': float(api_data['dividend'])/4,
											  'ex_dividend_date': api_data['ex_dividend_date'],
											  'payment_date': api_data['pay_date'],
											  'yield_y': api_data['dividend_yield']
										  })