from django.contrib import admin
from screener.models import Stock
class StockAdmin(admin.ModelAdmin):
    search_fields=('ticker',)
admin.site.register(Stock,StockAdmin)