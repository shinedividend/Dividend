from django.shortcuts import redirect, render
from django.db.models import F, Q
from django.shortcuts import get_object_or_404
from screener.models import Stock
from databank.models import Stock as DataBankStock
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from datetime import datetime
import pandas as pd
from api_data import *

def homepage(request):
    return render(request, 'screener/homepage.html')


@login_required
def screener(request):
    if request.method == 'POST' and 'watchlist' in request.POST:
        symbol = request.POST.get('symbol')
        symbol = symbol.upper()
        api_data = add_stock(symbol)
        Stock.objects.update_or_create(ticker=symbol, defaults={
            'company_name': api_data['company_name'],
            'exchange': api_data['exchange'],
            'last': api_data['last'],
            'price': api_data['price'],
            'change': api_data['change'],
            'change_percent': api_data['changePercent'],
            'high': api_data['high'],
            'low': api_data['low'],
            'volume': api_data['volume'],
            # 'time': datetime.strftime(datetime.strptime(api_data['time'], '%B %d, %Y'), '%Y-%m-%d'),
        })
    if request.method == 'POST' and 'delete-screener-button' in request.POST:
        symbol = request.POST.get('add-symbol')
        symbol = symbol.upper()
        exchange = request.POST.get('add-exchange')
        Stock.objects.get(ticker=symbol, exchange=exchange).delete()
    elif request.method == 'POST' and 'add-databank-button' in request.POST:
        symbol = request.POST.get('add-symbol')
        symbol = symbol.upper()
        api_data = get_dividend(symbol)
        DataBankStock.objects.update_or_create(ticker=symbol, defaults={
            'company_name': api_data['company_name'],
            'sector': api_data['sector'],
            'price': api_data['price'],
            'dividend': api_data['dividend'],
            'dividend_yield': api_data['dividend_yield'],
            'ex_dividend_date': api_data['ex_dividend_date'],
            'payment_date': api_data['pay_date'],
        })
        return redirect('/databank')
    stocks = Stock.objects.all().order_by('ticker')
    paginator = Paginator(stocks, 100)
    page = request.GET.get('page')
    stocks = paginator.get_page(page)
    context = {
        'stocks': stocks,
    }
    return render(request, 'screener/screener.html', context)


@login_required
def search_stock(request):
    if request.method == 'GET':
        query = request.GET['search-text']
        if query:
            stocks = Stock.objects.filter(Q(ticker__icontains=query) | Q(company_name__icontains=query))
            if stocks:
                paginator = Paginator(stocks, 30)
                page = request.GET.get('page')
                stocks = paginator.get_page(page)
                return render(request, 'screener/search_stock.html', {'stocks': stocks, })
            else:
                return render(request, 'screener/search_stock.html', {'error': 'No query matched.', })
        else:
            return render(request, 'screener/search_stock.html', {'error': 'Please enter something to search.'})
    return render(request, 'screener/search_stock.html')


@login_required
def watchlist(request):
    if request.method == 'POST' and 'watchlist' in request.POST:
        symbol = request.POST.get('symbol')
        symbol = symbol.upper()
        api_data = add_stock(symbol)
        Stock.objects.update_or_create(ticker=symbol, defaults={
            'company_name': api_data['company_name'],
            'exchange': api_data['exchange'],
            'price': api_data['price'],
            'last': api_data['last'],
            'change': api_data['change'],
            'change_percent': api_data['changePercent'],
            'high': api_data['high'],
            'low': api_data['low'],
            'volume': api_data['volume'],
            # 'time': api_data['time'],
        })
    elif request.method == 'POST' and 'add-databank-button' in request.POST:
        symbol = request.POST.get('add-symbol')
        symbol = symbol.upper()
        api_data = add_stock(symbol)
        DataBankStock.objects.update_or_create(ticker=symbol, defaults={
            'company_name': api_data['company_name'],
            'exchange': api_data['exchange'],
            'sector': api_data['sector'],
            'price': api_data['price'],
            'frequency': api_data['frequency'],
            'dividend': api_data['dividend'],
            'dividend_yield': api_data['dividend_yield'],
            'ex_dividend_date': api_data['ex_dividend_date'],
            'payment_date': api_data['pay_date'],
        })
        return redirect('/databank')
    stocks = Stock.objects.all().order_by('-created_at')
    paginator = Paginator(stocks, 100)
    page = request.GET.get('page')
    stocks = paginator.get_page(page)
    return render(request, 'screener/stockstracker.html', {'stocks': stocks})


def upload_data(request):
    # df = pd.read_csv('data-us.csv')
    # for index, row in df.iterrows():
    #     Stock.objects.update_or_create(ticker=row['Symbol'], defaults={
    #         'company_name': row['Name'],
    #         'last': row['Last'],
    #         'change': row['Change'],
    #         'change_percent': float(str(row['%Chg']).replace('%', '')),
    #         'high': row['High'],
    #         'low': row['Low'],
    #         'volume': row['Volume'],
    #     })
    return redirect('/screener')


def add_stock(symbol):
    api_data = get_qoute(symbol)
    return api_data