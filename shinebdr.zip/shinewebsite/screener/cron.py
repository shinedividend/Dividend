from screener.models import *
from datetime import datetime
from api_data import *

def update_screener():
    stocks = Stock.objects.all().order_by('ticker')
    for stock in stocks:
        api_data = add_stock(stock)
        stock.company_name = api_data['company_name']
        stock.exchange = api_data['exchange']
        stock.price = api_data['price']
        stock.last = api_data['last']
        stock.change = api_data['change']
        stock.change_percent = api_data['changePercent']
        stock.high = api_data['high']
        stock.low = api_data['low']
        stock.volume = api_data['volume']
        stock.time = None
        stock.save()

def add_stock(stock):
    ticker = stock.ticker
    api_data = get_qoute(ticker)
    return api_data