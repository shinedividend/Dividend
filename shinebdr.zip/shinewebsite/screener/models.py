from django.db import models

class Stock(models.Model):
    ticker = models.CharField(max_length=20)
    company_name = models.CharField(max_length=100, null=True, blank=True)
    exchange = models.CharField(max_length=10, null=True, blank=True)
    price = models.FloatField(null=True, blank=True)
    last = models.FloatField(null=True, blank=True)
    change = models.FloatField(null=True, blank=True)
    change_percent = models.FloatField(null=True, blank=True)
    high = models.FloatField(null=True, blank=True)
    low = models.FloatField(null=True, blank=True)
    volume = models.BigIntegerField(null=True, blank=True)
    time = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ticker

class Watchlist(models.Model):
    ticker = models.ForeignKey(Stock, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
