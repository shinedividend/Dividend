from django.urls import path
from screener import views

urlpatterns = [
    path('screener/', views.screener),
    path('watchlist/', views.watchlist),
    path('upload/', views.upload_data),
]