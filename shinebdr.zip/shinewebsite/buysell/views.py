from django.shortcuts import render, redirect
from portfolio.models import *
from django.contrib.auth.decorators import login_required

@login_required
def homepage(request):
	portfolios = PortfolioStock.objects.values_list('portfolio_name', flat=True)
	portfolios = list(set(portfolios))
	if request.method == 'POST' and 'btnform' in request.POST:
		symbol = request.POST.get('symbol')
		symbol = symbol.upper()
		exchange = request.POST.get('exchange')
		portfolio_name = request.POST.get('portfolio')
		initial_investment = request.POST.get('initial-investment')
		commision = request.POST.get('commision')
		portfolio(symbol, exchange, float(initial_investment), float(commision), portfolio_name)
		return redirect('/portfolio')
	if request.method == 'POST' and 'cashbalancebtn' in request.POST:
		cash_balance = request.POST.get('cashbalance')
		if cash_balance.isnumeric():
			with open('cash_balance.txt', 'w') as f:
				f.write(cash_balance)
	with open('cash_balance.txt', 'r') as f:
		cash_balance = f.read()
		if cash_balance is None:
			cash_balance = 0
	return render(request, 'buysell/homepage.html', {'portfolios': portfolios, 'cash_balance': cash_balance})

def portfolio(ticker, exchange, initial_investment, commission, portfolio_name):
	import requests
	url = "https://apidojo-yahoo-finance-v1.p.rapidapi.com/stock/v2/get-summary"
	if exchange == 'TSX':
		querystring = {"symbol": f"{ticker}.TO"}
	elif exchange == 'CN':
		querystring = {"symbol": f"{stock.ticker}.CN"}
	elif exchange == 'TSXV':
		querystring = {"symbol": f"{stock.ticker}.V"}
	else:
		querystring = {"symbol": f"{stock.ticker}"}
	headers = {
		'x-rapidapi-key': "1daf6011a7msh3ca3335d920fbb1p1730edjsn9aca9e27c423",
		'x-rapidapi-host': "apidojo-yahoo-finance-v1.p.rapidapi.com"
	}
	response = requests.request("GET", url, headers=headers, params=querystring)
	json_dict = response.json()
	api_data = {}
	quote = json_dict['quoteType']
	if quote:
		api_data['company_name'] = quote['longName']
	try:
		api_data['price'] = json_dict['financialData']['currentPrice']['fmt']
	except:
		api_data['price'] = 0
	try:
		api_data['sector'] = json_dict['summaryProfile']['sector']
	except:
		api_data['sector'] = None
	summary = json_dict['summaryDetail']
	if summary:
		try:
			api_data['dividend_yield'] = summary['dividendYield']['raw'] * 100
		except:
			api_data['dividend_yield'] = 0
	else:
			api_data['dividend_yield'] = 0
	if exchange == 'TSX' or exchange == 'CSE':
		currency = 'CAD'
	else:
		currency = 'USD'
	price = float(api_data['price'])
	Cash_Available_for_INVESTMENT_Q1 = initial_investment - commission
	quantity = int(Cash_Available_for_INVESTMENT_Q1 / price)
	avg_cost = (quantity*price)+commission
	avg_cost = avg_cost/quantity
	mkt_value = quantity * price
	book_cost = quantity * avg_cost
	gain_loss = mkt_value - book_cost
	PortfolioStock.objects.update_or_create(ticker=ticker, portfolio_name=portfolio_name,
													 defaults={
														 'company_name':api_data['company_name'],
														 'sector':api_data['sector'],
														 'currency': currency,
														 'price': price,
														 'quantity':quantity,
														 'avg_cost':avg_cost,
														 'mkt_value':mkt_value,
														 'book_cost':book_cost,
														 'gain_loss':gain_loss,
														 'glpercentage':gain_loss/book_cost * 100,
														 'stock_yield':api_data['dividend_yield'],
													 })