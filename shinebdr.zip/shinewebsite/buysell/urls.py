from django.urls import path
from buysell import views

urlpatterns = [
    path('', views.homepage),
]