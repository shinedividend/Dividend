from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import *
from summary.models import *
from django.db.models import Avg, Sum
import plotly.express as px
from plotly.offline import plot
@login_required
def homepage(request):
    portfolios = PortfolioStock.objects.values_list('portfolio_name', flat=True)
    portfolio = portfolios.first()
    portfolios = list(set(portfolios))
    currency = "CAD"
    if request.method == 'POST':
        ticker = request.POST.get('delete_symbol')
        portfolio = request.POST.get('delete_portfolio')
        currency = request.POST.get('delete_currency')
        PortfolioStock.objects.get(ticker=ticker, portfolio_name=portfolio, currency=currency).delete()
        try:
            SummaryStock.objects.get(ticker=ticker, portfolio_name=portfolio, currency=currency).delete()
        except:
            pass
    elif request.method == 'GET' and 'submitbtn' in request.GET:
        currency = request.GET['currency']
        portfolio = request.GET['portfolio']
    total, plt_div = calculate(currency, portfolio)
    stocks = PortfolioStock.objects.filter(currency=currency, portfolio_name=portfolio)
    return render(request, 'portfolio/homepage.html', {
        'stocks': stocks,
        'plt_div': plt_div,
        'portfolios': portfolios,
        'total': total,
    })

def calculate(currency, portfolio):
    total = {}
    cal = PortfolioStock.objects.filter(currency=currency, portfolio_name=portfolio)
    mkt_value = cal.aggregate(Sum('mkt_value'))['mkt_value__sum']
    total['mkt_value'] = mkt_value
    total['book_cost'] = cal.aggregate(Sum('book_cost'))['book_cost__sum']
    total['gain_loss'] = cal.aggregate(Sum('gain_loss'))['gain_loss__sum']
    total['glpercentage'] = cal.aggregate(Avg('glpercentage'))['glpercentage__avg']
    total['stock_yield'] = cal.aggregate(Avg('stock_yield'))['stock_yield__avg']
    with open('cash_balance.txt', 'r') as f:
        cash_balance = f.read()
        if cash_balance is None:
            cash_balance = 0
    total['cash_balance'] = float(cash_balance)
    total['total_value'] = mkt_value + float(cash_balance)
    total['currency'] = currency

    for c in cal:
        c.portfolio_percentage = c.mkt_value / mkt_value
        c.save()

    random_x = cal.values_list('portfolio_percentage', flat=True)
    names = cal.values_list('ticker', flat=True)
    fig = px.pie(values=random_x, names=names, hole=.3,)
    fig.update_layout(
        # autosize=True,
        margin=dict(t=60, b=60, l=0, r=0),
        title={
            'text': 'Stock Percentage',
            'y': 0.9
        },
        font=dict(
            size=15,
            color="#198754"
        ),
    )
    plt_div = plot(fig, output_type='div', include_plotlyjs=False)

    return total, plt_div

def calculations(initial_investment, commission, api_data, year_number):
	y1, y2 = {}, {}
	if year_number >= 1:
		Share_Price = float(api_data['price'])
		dividend = float(api_data['dividend']) / 4
		y1['initial_investment'] = initial_investment
		y1['commission'] = commission
		Cash_Available_for_INVESTMENT_Y1 = initial_investment - commission
		y1['Cash_Available_for_INVESTMENT_Y1'] = Cash_Available_for_INVESTMENT_Y1
		potential_shares_for_investment = Cash_Available_for_INVESTMENT_Y1 / Share_Price
		y1['potential_shares_for_investment'] = potential_shares_for_investment
		y1['No_of_Shares_bought_in_Y1'] = int(potential_shares_for_investment)
		share_percentage_after_investment_in_Y1 = potential_shares_for_investment - int(potential_shares_for_investment)
		y1['Share_Percentage_after_investment_in_Y1'] = share_percentage_after_investment_in_Y1
		y1['investment_cash_Y1'] = int(potential_shares_for_investment) * Share_Price
		y1['CASH_BALANCE_in_Account_after_Investment_Y1'] = Share_Price * share_percentage_after_investment_in_Y1
		Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 = int(potential_shares_for_investment) * dividend
		y1['dividend_cash_received_WITHOUT_DRIP_in_Y1'] = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1
		potential_number_of_drip_shares_in_Y1 = Dividend_Cash_Received_WITHOUT_DRIP_in_Y1 / Share_Price
		y1['potential_number_of_drip_shares_in_Y1'] = potential_number_of_drip_shares_in_Y1
		y1['no_of_drip_shares_received_in_Y1'] = int(potential_number_of_drip_shares_in_Y1)
		share_percentage_cash_balance_after_drip = potential_number_of_drip_shares_in_Y1 - int(potential_number_of_drip_shares_in_Y1)
		y1['share_percentage_cash_balance_after_drip_Y1'] = share_percentage_cash_balance_after_drip
		y1['cash_balance_received_WITH_DRIP_in_Y1'] = share_percentage_cash_balance_after_drip * Share_Price
		Total_No_of_Shares_With_Drip_end_of_Y1 = int(potential_shares_for_investment) + int(potential_number_of_drip_shares_in_Y1)
		y1['total_no_of_shares_with_drip_end_of_Y1'] = Total_No_of_Shares_With_Drip_end_of_Y1
		Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y2_WITH_DRIP = Share_Price * Total_No_of_Shares_With_Drip_end_of_Y1
		y1['Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP1'] = Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y2_WITH_DRIP
	if year_number >= 2:
		for i in range(2,year_number+1):
			dividend_cash_received_WITHOUT_DRIP_in_Y = Total_No_of_Shares_With_Drip_end_of_Y1 * dividend
			y2['dividend_cash_received_WITHOUT_DRIP_in_Y' + str(i)] = dividend_cash_received_WITHOUT_DRIP_in_Y
			potential_number_of_drip_shares_in_Y = dividend_cash_received_WITHOUT_DRIP_in_Y / Share_Price
			y2['potential_number_of_drip_shares_in_Y' + str(i)] = potential_number_of_drip_shares_in_Y
			y2['no_of_drip_shares_received_in_Y' + str(i)] = int(potential_number_of_drip_shares_in_Y)
			share_percentage_cash_balance_after_drip = potential_number_of_drip_shares_in_Y - int(potential_number_of_drip_shares_in_Y)
			y2['share_percentage_cash_balance_after_drip_Y' + str(i)] = share_percentage_cash_balance_after_drip
			y2['cash_balance_received_WITH_DRIP_in_Y' + str(i)] = share_percentage_cash_balance_after_drip * Share_Price
			Total_No_of_Shares_With_Drip_end_of_Y1 = Total_No_of_Shares_With_Drip_end_of_Y1 + int(potential_number_of_drip_shares_in_Y)
			y2['total_no_of_shares_with_drip_end_of_Y' + str(i)] = Total_No_of_Shares_With_Drip_end_of_Y1
			Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP = Share_Price * Total_No_of_Shares_With_Drip_end_of_Y1
			y2['Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP' + str(i)] = Total_Portfolio_CASH_Available_for_INVESTMENT_in_Y_WITH_DRIP
	return y1,y2