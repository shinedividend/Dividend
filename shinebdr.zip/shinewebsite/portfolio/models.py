from django.db import models

class PortfolioStock(models.Model):
    portfolio_name = models.TextField()
    ticker = models.CharField(max_length=20)
    company_name = models.CharField(max_length=100, null=True, blank=True)
    sector = models.CharField(max_length=100, null=True, blank=True)
    currency = models.CharField(max_length=5, null=True, blank=True)
    quantity = models.IntegerField(null=True, blank=True)
    price = models.FloatField(null=True, blank=True)
    avg_cost = models.FloatField(null=True, blank=True)
    mkt_value = models.FloatField(null=True, blank=True)
    book_cost = models.FloatField(null=True, blank=True)
    gain_loss = models.FloatField(null=True, blank=True)
    glpercentage = models.FloatField(null=True, blank=True)
    portfolio_percentage = models.FloatField(null=True, blank=True)
    stock_yield = models.FloatField(null=True, blank=True)
    cash_balance = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ticker